__version__ = "2.2"

from selenium_profiles.driver import driver, sendkeys, navigator2profile
